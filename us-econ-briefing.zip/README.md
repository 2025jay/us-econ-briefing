# ☕ 미국 경제 AI 브리핑

매일 한국시간 **오전 8:30**, **오후 8:30**에 새 미국 경제 브리핑이 자동으로 게시되는 웹앱.

`uploads/news_webapp_brief.md` 사양 기반.

---

## 📦 현재 상태 — Phase 1 완료

이 커밋은 **Phase 1 (프론트엔드 정적 모킹)** 까지 포함합니다.

- ✅ Next.js 14 App Router + TypeScript + TailwindCSS 셋업
- ✅ 디자인 시스템 (베이지/네오브루탈리스트, Jua/Pretendard/Single Day/JetBrains Mono)
- ✅ 메인 페이지 `/` (시장 위젯 + 오늘 브리핑 + 최근 브리핑 슬라이더)
- ✅ 브리핑 상세 `/briefing/[date]/[session]`
- ✅ 아카이브 `/archive` (월별 그룹)
- ✅ 로그인 placeholder `/login`
- ✅ Supabase 스키마 SQL (`supabase/schema.sql`)
- ⏳ Phase 2: Supabase 연결 + 기존 `news_bot.py` Railway 이전 + DB insert
- ⏳ Phase 3: NextAuth + Google 로그인 + 활동 로그
- ⏳ Phase 4: Vercel 배포 + 봇 운영 검증

---

## 🚀 로컬에서 띄우기

```bash
# 1. 의존성 설치 (node 18+ 필요)
npm install

# 2. 개발 서버 실행
npm run dev

# 3. 브라우저 → http://localhost:3000
```

Phase 1은 `lib/mockData.ts`의 정적 데이터만 사용하므로 환경변수 없이 그대로 동작합니다.

---

## 🎨 디자인 토큰

`tailwind.config.ts`에서 한 곳에 정의돼 있어요.

| 토큰 | 값 | 용도 |
|---|---|---|
| `bg-paper` | `#FAF3E0` | 베이지 페이지 배경 |
| `text-ink` | `#1A1A1A` | 기본 잉크 텍스트 |
| `bg-accent-pink` | `#ED4983` | 카드 액센트 1 |
| `bg-accent-lime` | `#C8E853` | 카드 액센트 2 (상승) |
| `bg-accent-yellow` | `#F8D742` | 카드 액센트 3 (CTA) |
| `bg-accent-purple` | `#C8B4F0` | 카드 액센트 4 |
| `bg-accent-blue` | `#A8C9E8` | 카드 액센트 5 |
| `shadow-brutal` | 4×4 black | 네오브루탈리스트 드롭섀도우 |
| `font-display` | Jua | 둥근 한글 디스플레이 (큰 제목) |
| `font-sans` | Pretendard | 본문 |
| `font-handwriting` | Single Day | 손글씨 강조 |
| `font-mono` | JetBrains Mono | 숫자/영문 |
| `pen-highlight` | CSS class | 형광펜 강조 효과 |

---

## 📁 파일 구조

```
미국 경제 AI 브리핑/
├── app/
│   ├── layout.tsx               # 폰트 로딩 + 공통 메타데이터
│   ├── page.tsx                 # 메인 /
│   ├── globals.css              # Tailwind + Pretendard CDN
│   ├── not-found.tsx            # 404
│   ├── briefing/[date]/[session]/page.tsx   # 상세 페이지
│   ├── archive/page.tsx         # 아카이브
│   └── login/page.tsx           # 로그인 (placeholder)
├── components/
│   ├── Header.tsx
│   ├── Footer.tsx
│   ├── MarketWidget.tsx         # S&P/NASDAQ/DOW 위젯
│   ├── BriefingCard.tsx         # full / compact 두 variant
│   └── ShareButton.tsx          # Client Component (navigator.share)
├── lib/
│   ├── types.ts                 # DB 스키마 매칭 TypeScript 타입
│   ├── mockData.ts              # Phase 1 정적 데이터 (Phase 2에서 교체)
│   └── format.ts                # 포매팅 헬퍼
├── supabase/
│   └── schema.sql               # Phase 2에서 사용
├── _previous_rss_attempt/       # (무시) 이전 시도 보관 — git에서 제외됨
├── package.json
├── tailwind.config.ts           # 디자인 토큰
├── tsconfig.json
├── next.config.mjs
└── .env.example
```

---

## 🔜 Phase 2 시작 시 받아야 할 것

`uploads/news_webapp_brief.md`의 "코워크가 사용자한테 받아야 할 것" 섹션 그대로:

1. **기존 봇 코드 zip** — `news_bot.py`, `card_news_generator.py`, `gmail_sender.py`, `requirements.txt`, `cardnews/index.html` 등 (민감 파일 제외)
2. **Anthropic API 키** (`ANTHROPIC_API_KEY`)
3. **Unsplash API 키** (`UNSPLASH_ACCESS_KEY`)
4. **기존 OAuth 토큰들** (`kakao_token.json`, `google_credentials.json`, `token.json`)
5. **Supabase 프로젝트** — https://supabase.com 에서 새 프로젝트 만들고 URL + anon key + service role key 전달
6. **Google OAuth Client ID/Secret** (Phase 3 — https://console.cloud.google.com)
7. **도메인** (선택)

---

## 💰 비용 추정 (brief 기준)

| 항목 | 월 비용 |
|---|---|
| Vercel (Hobby) | $0 |
| Supabase (Free tier, 500MB) | $0 |
| Railway (Hobby, 봇 24/7) | $5 |
| Anthropic API (Sonnet 일 2회) | ~$6 |
| Unsplash | $0 |
| yfinance | $0 |
| **합계** | **~$11/월** + 도메인 별도 |

---

## 🛠 트러블슈팅

**Q. `npm run dev` 했더니 Pretendard 폰트가 안 보임**
→ CDN 차단 환경일 수 있어요. `app/globals.css`의 `@import url("https://cdn.jsdelivr.net/...")` 를 self-host로 바꾸거나 시스템 sans-serif로 fallback돼 표시됩니다.

**Q. TailwindCSS 클래스가 적용 안 됨**
→ `node_modules/.cache`나 `.next/` 폴더 지우고 다시 `npm run dev`.

**Q. 카드뉴스 PNG는 어디?**
→ Brief 명세에 따라 사이트엔 표시하지 않습니다. 본인 메일/카톡 발송은 기존 봇이 계속 담당.
