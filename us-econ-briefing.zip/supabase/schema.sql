-- 미국 경제 AI 브리핑 — Supabase 스키마
-- 사용법: Supabase 대시보드 → SQL Editor → 붙여넣기 → Run

-- ──────────────────────────────────────────────────────────────
-- 1. 브리핑 본문
-- ──────────────────────────────────────────────────────────────
create table if not exists briefings (
  id uuid primary key default gen_random_uuid(),
  session_date date not null,
  session_time text not null check (session_time in ('morning', 'evening')),
  market_status jsonb,
    -- { sp500: {value, change, change_pct}, nasdaq: {...}, dow: {...}, as_of: text }
  briefing_intro text,
  items jsonb,
    -- [{ title, body, source }, ...]
  generated_at timestamptz default now(),
  unique (session_date, session_time)
);

create index if not exists briefings_session_date_idx
  on briefings (session_date desc, session_time desc);

-- ──────────────────────────────────────────────────────────────
-- 2. 사용자 (Google 로그인)
-- ──────────────────────────────────────────────────────────────
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  google_id text unique not null,
  email text not null,
  name text,
  avatar_url text,
  created_at timestamptz default now(),
  last_login timestamptz
);

-- ──────────────────────────────────────────────────────────────
-- 3. 활동 로그 (선택)
-- ──────────────────────────────────────────────────────────────
create table if not exists activity_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  action text,  -- 'view_briefing', 'share', 'login', etc.
  briefing_id uuid references briefings(id) on delete set null,
  created_at timestamptz default now()
);

create index if not exists activity_log_user_idx
  on activity_log (user_id, created_at desc);

-- ──────────────────────────────────────────────────────────────
-- 4. RLS — 콘텐츠는 누구나 read, write는 service role만
-- ──────────────────────────────────────────────────────────────
alter table briefings enable row level security;
alter table users enable row level security;
alter table activity_log enable row level security;

drop policy if exists "briefings public read" on briefings;
create policy "briefings public read"
  on briefings for select
  using (true);

drop policy if exists "users self read" on users;
create policy "users self read"
  on users for select
  using (auth.uid()::text = google_id or auth.role() = 'service_role');

drop policy if exists "activity self read" on activity_log;
create policy "activity self read"
  on activity_log for select
  using (
    user_id in (select id from users where google_id = auth.uid()::text)
    or auth.role() = 'service_role'
  );
